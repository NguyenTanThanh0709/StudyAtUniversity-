package Bai05;

public class Main {
    
public static void main(String[] args) {
    House house1 = new House();

    System.out.println(house1);
    System.out.println(house1.getHouseCode());
    
    }
}
