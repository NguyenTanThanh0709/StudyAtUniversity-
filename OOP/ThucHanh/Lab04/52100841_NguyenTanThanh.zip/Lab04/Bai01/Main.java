package Bai01;

public class Main {
    public static void main(String[] args) {
        Point2D p1 = new Point2D(1.4, 2.4);

        System.out.println(p1.getX());
    }
}
