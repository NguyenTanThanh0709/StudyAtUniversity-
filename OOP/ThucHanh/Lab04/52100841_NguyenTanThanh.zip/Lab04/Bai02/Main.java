package Bai02;
public class Main {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(2,3);
        System.out.println(r1.getArea());
        System.out.println(r1.getPerimeter());
        System.out.println(r1);
    }
}
