public class Test {
    public static void main(String[] args) {
        Employee epl = new Employee("B01", "Nguyen Van Hau", 2000, "Administration");
        Employee epl2 = new Employee("B02", "Nguyen Van Hau", 2000, "Administratio11");
        // System.out.println("eID: " + epl.geteID());
        // System.out.println(epl2.geteDept());
    }
}