public class NumberOutOfRangeException extends Exception{
    public NumberOutOfRangeException(){
        super();
    }
    public NumberOutOfRangeException(String s){
        super(s);
    }
}