public class bai03 {
    public static void main(String[] args){
        float Fahrenheit = 54;
        float Celsius;
        Celsius = (float)5/9 * (Fahrenheit - 32);
        System.out.println(Fahrenheit + " do F sang do C la : " +  Celsius);

        float F;
        float C = 12;
        F = (float)5/9 * C+32;
        System.out.println(C + " do c sang do f la : " + F);
    }
}