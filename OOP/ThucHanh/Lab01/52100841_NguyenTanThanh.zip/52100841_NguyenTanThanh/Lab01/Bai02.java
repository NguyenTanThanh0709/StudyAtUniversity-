public class Bai02 {
    public static void main(String[] args){
        double area = 0;
        int base = 2;
        int height = 4;
        area = 1.0/2 * base * height;
        System.out.println("area = " + area);
    }
}