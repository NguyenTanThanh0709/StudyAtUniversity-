public class Bai01 {
    public static void main(String[] args){
        String name = "Nguyen Tan Thanh";
        int  day = 07, month = 9, year = 2003;
        int ID = 52100841;
		System.out.println("name : " + name);
        System.out.println("birth day : " + day + "/"+ month + "/"+ year);
        System.out.println("ID : " + ID);
    }
}