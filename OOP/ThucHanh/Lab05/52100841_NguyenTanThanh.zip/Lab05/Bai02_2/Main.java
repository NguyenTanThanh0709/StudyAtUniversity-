
public class Main {
    public static void main(String[] args) {
        Club c1 = new Club("Manchester United", 10, 5, 5);
        RegularPolygon rp1 = new RegularPolygon("Triangle", 3, 5);

        System.out.println(c1);
        System.out.println(rp1);
    }
}
