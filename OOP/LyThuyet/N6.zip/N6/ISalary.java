public interface  ISalary {
    public double getSalary();
}
